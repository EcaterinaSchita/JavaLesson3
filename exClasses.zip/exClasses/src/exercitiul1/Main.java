package exercitiul1;

public class Main {
    public static void main(String[] args) {
        System.out.println(Calculator.Sum(5, 8));
        System.out.println(Calculator.Impartire(9, 5));
        System.out.println(Calculator.Putere(2,3));
        System.out.println(Calculator.Inmultirea(14,13));
        System.out.println(Calculator.Scadere(10,11));
    }
//        System.out.println(fact((5));
//
//    }
//    static int fact (int n ){
//        int result = 1;
//        for (int i = 1; i<= n; i++){
//            result = result * i;
//
//        }
//        return result;
//    }
//        Student Jaka = new Student("Jaka" , 16 , "Informatics" ,  10);
//        System.out.println(Jaka.name);
//        System.out.println(Jaka.age);
////        System.out.println("lucreaza");
//        Student Lena = new Student();
////        System.out.println("Lena's mark is "+ Lena.mark);
//        Lena.mark = 9;
//        Lena.name = "Lena Trandafirenko";
//        System.out.println(Lena.name + "'s mark is " + Lena.mark );
//
//        Student Katea = new Student ();
//        System.out.println(Katea.name + "'s mark is " + Katea.name);
//
//        Lena.Learning();
//        Lena.Working();
//        Lena.Swimming();
//
//        String LenasCourse = Lena.showCourse();
//        System.out.println("Lena is on" + LenasCourse + "course");
//
//        Lena.setStudentCourse("Math and Logic");
//
//        LenasCourse = Lena.showCourse();
//        System.out.println("Lena is on " + LenasCourse + "course");
//
//
//    }
}
